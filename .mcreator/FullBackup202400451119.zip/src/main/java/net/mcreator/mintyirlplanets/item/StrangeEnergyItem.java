
package net.mcreator.mintyirlplanets.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class StrangeEnergyItem extends Item {
	public StrangeEnergyItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
