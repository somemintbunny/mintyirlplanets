
package net.mcreator.mintyirlplanets.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AntimatterItem extends Item {
	public AntimatterItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.RARE));
	}
}
