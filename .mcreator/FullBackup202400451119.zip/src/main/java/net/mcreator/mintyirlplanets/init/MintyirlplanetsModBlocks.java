
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mintyirlplanets.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.mintyirlplanets.block.TheMoonPortalBlock;
import net.mcreator.mintyirlplanets.block.TerraceliumMossBlock;
import net.mcreator.mintyirlplanets.block.SiverOreBlock;
import net.mcreator.mintyirlplanets.block.SiverBlockBlock;
import net.mcreator.mintyirlplanets.block.MoonshroomStemBlock;
import net.mcreator.mintyirlplanets.block.MoonshroomSporesconnectorBlock;
import net.mcreator.mintyirlplanets.block.MoonshroomSporesBlock;
import net.mcreator.mintyirlplanets.block.MoonshroomMossBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2WoodBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2StairsBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2SlabBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2PressurePlateBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2PlanksBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2LogBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2LeavesBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2FenceGateBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2FenceBlock;
import net.mcreator.mintyirlplanets.block.Moonshroom2ButtonBlock;
import net.mcreator.mintyirlplanets.block.MoonRockBlock;
import net.mcreator.mintyirlplanets.block.MarsPortalBlock;
import net.mcreator.mintyirlplanets.block.KryptoniumOreBlock;
import net.mcreator.mintyirlplanets.block.KryptoniumBlockBlock;
import net.mcreator.mintyirlplanets.block.FerrousSandBlock;
import net.mcreator.mintyirlplanets.block.DreamdropOreBlock;
import net.mcreator.mintyirlplanets.block.DreamdropBlockBlock;
import net.mcreator.mintyirlplanets.block.DarkMoonRockBlock;
import net.mcreator.mintyirlplanets.block.DamnedWoodBlock;
import net.mcreator.mintyirlplanets.block.DamnedStairsBlock;
import net.mcreator.mintyirlplanets.block.DamnedSlabBlock;
import net.mcreator.mintyirlplanets.block.DamnedPressurePlateBlock;
import net.mcreator.mintyirlplanets.block.DamnedPlanksBlock;
import net.mcreator.mintyirlplanets.block.DamnedLogBlock;
import net.mcreator.mintyirlplanets.block.DamnedLeavesBlock;
import net.mcreator.mintyirlplanets.block.DamnedFenceGateBlock;
import net.mcreator.mintyirlplanets.block.DamnedFenceBlock;
import net.mcreator.mintyirlplanets.block.DamnedButtonBlock;
import net.mcreator.mintyirlplanets.block.AluminumOreBlock;
import net.mcreator.mintyirlplanets.block.AluminumBlockBlock;
import net.mcreator.mintyirlplanets.block.AlumineumBlockBlock;
import net.mcreator.mintyirlplanets.MintyirlplanetsMod;

public class MintyirlplanetsModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(MintyirlplanetsMod.MODID);
	public static final DeferredBlock<Block> MOON_ROCK = REGISTRY.register("moon_rock", MoonRockBlock::new);
	public static final DeferredBlock<Block> DARK_MOON_ROCK = REGISTRY.register("dark_moon_rock", DarkMoonRockBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_MOSS = REGISTRY.register("moonshroom_moss", MoonshroomMossBlock::new);
	public static final DeferredBlock<Block> TERRACELIUM_MOSS = REGISTRY.register("terracelium_moss", TerraceliumMossBlock::new);
	public static final DeferredBlock<Block> THE_MOON_PORTAL = REGISTRY.register("the_moon_portal", TheMoonPortalBlock::new);
	public static final DeferredBlock<Block> DREAMDROP_ORE = REGISTRY.register("dreamdrop_ore", DreamdropOreBlock::new);
	public static final DeferredBlock<Block> DREAMDROP_BLOCK = REGISTRY.register("dreamdrop_block", DreamdropBlockBlock::new);
	public static final DeferredBlock<Block> DAMNED_WOOD = REGISTRY.register("damned_wood", DamnedWoodBlock::new);
	public static final DeferredBlock<Block> DAMNED_LOG = REGISTRY.register("damned_log", DamnedLogBlock::new);
	public static final DeferredBlock<Block> DAMNED_PLANKS = REGISTRY.register("damned_planks", DamnedPlanksBlock::new);
	public static final DeferredBlock<Block> DAMNED_LEAVES = REGISTRY.register("damned_leaves", DamnedLeavesBlock::new);
	public static final DeferredBlock<Block> DAMNED_STAIRS = REGISTRY.register("damned_stairs", DamnedStairsBlock::new);
	public static final DeferredBlock<Block> DAMNED_SLAB = REGISTRY.register("damned_slab", DamnedSlabBlock::new);
	public static final DeferredBlock<Block> DAMNED_FENCE = REGISTRY.register("damned_fence", DamnedFenceBlock::new);
	public static final DeferredBlock<Block> DAMNED_FENCE_GATE = REGISTRY.register("damned_fence_gate", DamnedFenceGateBlock::new);
	public static final DeferredBlock<Block> DAMNED_PRESSURE_PLATE = REGISTRY.register("damned_pressure_plate", DamnedPressurePlateBlock::new);
	public static final DeferredBlock<Block> DAMNED_BUTTON = REGISTRY.register("damned_button", DamnedButtonBlock::new);
	public static final DeferredBlock<Block> SIVER_ORE = REGISTRY.register("siver_ore", SiverOreBlock::new);
	public static final DeferredBlock<Block> SIVER_BLOCK = REGISTRY.register("siver_block", SiverBlockBlock::new);
	public static final DeferredBlock<Block> ALUMINUM_ORE = REGISTRY.register("aluminum_ore", AluminumOreBlock::new);
	public static final DeferredBlock<Block> ALUMINUM_BLOCK = REGISTRY.register("aluminum_block", AluminumBlockBlock::new);
	public static final DeferredBlock<Block> ALUMINEUM_BLOCK = REGISTRY.register("alumineum_block", AlumineumBlockBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_WOOD = REGISTRY.register("moonshroom_2_wood", Moonshroom2WoodBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_LOG = REGISTRY.register("moonshroom_2_log", Moonshroom2LogBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_PLANKS = REGISTRY.register("moonshroom_2_planks", Moonshroom2PlanksBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_LEAVES = REGISTRY.register("moonshroom_2_leaves", Moonshroom2LeavesBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_STAIRS = REGISTRY.register("moonshroom_2_stairs", Moonshroom2StairsBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_SLAB = REGISTRY.register("moonshroom_2_slab", Moonshroom2SlabBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_FENCE = REGISTRY.register("moonshroom_2_fence", Moonshroom2FenceBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_FENCE_GATE = REGISTRY.register("moonshroom_2_fence_gate", Moonshroom2FenceGateBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_PRESSURE_PLATE = REGISTRY.register("moonshroom_2_pressure_plate", Moonshroom2PressurePlateBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_2_BUTTON = REGISTRY.register("moonshroom_2_button", Moonshroom2ButtonBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_SPORESCONNECTOR = REGISTRY.register("moonshroom_sporesconnector", MoonshroomSporesconnectorBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_SPORES = REGISTRY.register("moonshroom_spores", MoonshroomSporesBlock::new);
	public static final DeferredBlock<Block> MOONSHROOM_STEM = REGISTRY.register("moonshroom_stem", MoonshroomStemBlock::new);
	public static final DeferredBlock<Block> KRYPTONIUM_ORE = REGISTRY.register("kryptonium_ore", KryptoniumOreBlock::new);
	public static final DeferredBlock<Block> KRYPTONIUM_BLOCK = REGISTRY.register("kryptonium_block", KryptoniumBlockBlock::new);
	public static final DeferredBlock<Block> FERROUS_SAND = REGISTRY.register("ferrous_sand", FerrousSandBlock::new);
	public static final DeferredBlock<Block> MARS_PORTAL = REGISTRY.register("mars_portal", MarsPortalBlock::new);
	public static final DeferredBlock<Block> CORESTONE = REGISTRY.register("corestone", CorestoneBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
