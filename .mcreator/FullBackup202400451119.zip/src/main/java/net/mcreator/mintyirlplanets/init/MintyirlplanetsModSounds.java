
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mintyirlplanets.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.mintyirlplanets.MintyirlplanetsMod;

public class MintyirlplanetsModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, MintyirlplanetsMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> DISC1 = REGISTRY.register("disc1", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("mintyirlplanets", "disc1")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DISC2 = REGISTRY.register("disc2", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("mintyirlplanets", "disc2")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DISC3 = REGISTRY.register("disc3", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("mintyirlplanets", "disc3")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DARKMOON = REGISTRY.register("darkmoon", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("mintyirlplanets", "darkmoon")));
}
