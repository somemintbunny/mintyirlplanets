
package net.mcreator.mintyirlplanets.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.mintyirlplanets.entity.EyezorEntity;

public class EyezorRenderer extends HumanoidMobRenderer<EyezorEntity, HumanoidModel<EyezorEntity>> {
	public EyezorRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<EyezorEntity>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(EyezorEntity entity) {
		return ResourceLocation.parse("mintyirlplanets:textures/entities/eyezor.png");
	}
}
