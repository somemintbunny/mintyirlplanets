
package net.mcreator.mintyirlplanets.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.mintyirlplanets.entity.TheCrusherEntity;
import net.mcreator.mintyirlplanets.client.model.Modelcrusher;

public class TheCrusherRenderer extends MobRenderer<TheCrusherEntity, Modelcrusher<TheCrusherEntity>> {
	public TheCrusherRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelcrusher<TheCrusherEntity>(context.bakeLayer(Modelcrusher.LAYER_LOCATION)), 2f);
	}

	@Override
	public ResourceLocation getTextureLocation(TheCrusherEntity entity) {
		return ResourceLocation.parse("mintyirlplanets:textures/entities/texture.png");
	}
}
