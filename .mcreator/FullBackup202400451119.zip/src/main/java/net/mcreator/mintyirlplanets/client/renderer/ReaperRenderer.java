
package net.mcreator.mintyirlplanets.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.mintyirlplanets.entity.ReaperEntity;
import net.mcreator.mintyirlplanets.client.model.Modelcustom_model;

public class ReaperRenderer extends MobRenderer<ReaperEntity, Modelcustom_model<ReaperEntity>> {
	public ReaperRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelcustom_model<ReaperEntity>(context.bakeLayer(Modelcustom_model.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ReaperEntity entity) {
		return ResourceLocation.parse("mintyirlplanets:textures/entities/texture2.png");
	}
}
