
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mintyirlplanets.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.mintyirlplanets.client.renderer.TheCrusherRenderer;
import net.mcreator.mintyirlplanets.client.renderer.ShrumpherRenderer;
import net.mcreator.mintyirlplanets.client.renderer.ReaperRenderer;
import net.mcreator.mintyirlplanets.client.renderer.MartianRenderer;
import net.mcreator.mintyirlplanets.client.renderer.EyezorRenderer;
import net.mcreator.mintyirlplanets.client.renderer.DebuggerRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MintyirlplanetsModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MintyirlplanetsModEntities.DEBUGGER.get(), DebuggerRenderer::new);
		event.registerEntityRenderer(MintyirlplanetsModEntities.REAPER.get(), ReaperRenderer::new);
		event.registerEntityRenderer(MintyirlplanetsModEntities.TOSSER_GRENADE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(MintyirlplanetsModEntities.LAZER.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(MintyirlplanetsModEntities.EYEZOR.get(), EyezorRenderer::new);
		event.registerEntityRenderer(MintyirlplanetsModEntities.THE_CRUSHER.get(), TheCrusherRenderer::new);
		event.registerEntityRenderer(MintyirlplanetsModEntities.MARTIAN.get(), MartianRenderer::new);
		event.registerEntityRenderer(MintyirlplanetsModEntities.SHRUMPHER.get(), ShrumpherRenderer::new);
	}
}
